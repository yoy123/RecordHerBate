#!/bin/bash

# Prompt for user input
read -p "Enter the model name for filename saving: " USERINPUT1
read -p "Enter the chunklist from network tab: " USERINPUT2

# Run VLC with the user input
cd ~/Downloads && \
/Applications/VLC.app/Contents/MacOS/VLC \
--sout="#standard{access=file,mux=mp4,dst=1-${USERINPUT1}.mp4}" \
"${USERINPUT2}" \
--adaptive-logic=highest vlc://quit
